package com.test.supersdkdemo;

import com.supersdk.application.SuperApplication;

public class GameApplication extends SuperApplication {

}
