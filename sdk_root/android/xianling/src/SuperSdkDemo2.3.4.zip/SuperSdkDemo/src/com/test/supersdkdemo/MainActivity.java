package com.test.supersdkdemo;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.supersdk.common.bean.GameInfor;
import com.supersdk.common.bean.SupersdkPay;
import com.supersdk.common.listen.CanEnterListen;
import com.supersdk.common.listen.GameInforListen;
import com.supersdk.common.listen.LoginListen;
import com.supersdk.common.listen.LogoutGameListen;
import com.supersdk.common.listen.LogoutListen;
import com.supersdk.common.listen.PayListen;
import com.supersdk.presenter.SuperHelper;
import com.supersdk.superutil.ToastUtils;

public class MainActivity extends Activity implements OnClickListener {
	private SuperHelper superHelper;
	private TextView tv_userInfo; // 日志文本
	private EditText edit_pay;
	private boolean iscanenter; // 是否允许进入服务器

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		superHelper = SuperHelper.geApi();
		superHelper.activity_creat(this, savedInstanceState);
		findViewById(R.id.btn_login).setOnClickListener(this);
		findViewById(R.id.btn_pay).setOnClickListener(this);
		findViewById(R.id.btn_logout).setOnClickListener(this);
		findViewById(R.id.btn_finish).setOnClickListener(this);
		findViewById(R.id.btn_uploadUserInfo).setOnClickListener(this);
		findViewById(R.id.btn_canenter).setOnClickListener(this);
		/*
		 * SDK注册监听,游戏内接收到监听,做注销游戏操作
		 */
		superHelper.register_logoutListen(new LogoutListen() {

			@Override
			public void defeat(String arg0) {
				// 注销失败,此处
			}

			@Override
			public void logout_success(String json) {
				// 注销成功,此处写游戏注销方法
				// 此处写游戏注销方法
				tv_userInfo.setTextColor(Color.BLACK);
				tv_userInfo.setText("注销成功" + "\n" + "" + json);
			}

			@Override
			public void logout_defeat(String arg0) {
				// 注销失败,
			}
		});
		tv_userInfo = (TextView) findViewById(R.id.tv_userInfo);
		edit_pay = (EditText) findViewById(R.id.edit_pay);
		if (superHelper != null) {
			tv_userInfo.setText("初始化成功");
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_login: // 登录
			SuperHelper.geApi().login(new LoginListen() {

				@Override
				public void defeat(String json) {
					tv_userInfo.setTextColor(Color.RED);
					tv_userInfo.setText("登录失败" + "\n" + "" + json);
					Log.e("zkf", json);

				}

				@Override
				public void login_defeat(String json) {
					tv_userInfo.setTextColor(Color.RED);
					tv_userInfo.setText("登录失败" + "\n" + "" + json);
					Log.e("zkf", json);
				}

				@Override
				public void login_success(String json) {
					tv_userInfo.setTextColor(Color.BLACK);
					tv_userInfo.setText("登录成功" + "\n" + "" + json);
					Log.e("zkf", json);
					try {
						JSONObject jo = new JSONObject(json);
						String super_user_id = jo.getString("super_user_id");
						String token = jo.getString("token");
						//以下两条实名信息不是必有，请做好兼容处理
						int auth = jo.getInt("auth");//0未实名 1已实名 2未接入实名
						String birthday = jo.getString("birthday");//出生日期，默认格式为 年-月-日，比如1990-1-1。如未实名或者没有实名信息可能为null或者空字符串
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}
			});
			break;
		case R.id.btn_logout:
			SuperHelper.geApi().logout(new LogoutListen() {

				@Override
				public void defeat(String defeat) {
					tv_userInfo.setTextColor(Color.RED);
					tv_userInfo.setText("注销失败" + "\n" + "" + defeat);
					Log.e("zkf", defeat);
				}

				@Override
				public void logout_success(String json) {
					Log.e("zkf", json);
					tv_userInfo.setTextColor(Color.BLACK);
					tv_userInfo.setText("注销成功" + "\n" + "" + json);
					iscanenter = false;
				}

				@Override
				public void logout_defeat(String string) {
					tv_userInfo.setTextColor(Color.RED);
					tv_userInfo.setText("注销失败" + "\n" + "" + string);
					Log.e("zkf", string);
				}
			});
			break;

		case R.id.btn_canenter: // 是否允许新增
			GameInfor gameInfor1 = new GameInfor();
			gameInfor1.setService_name("测试服1"); // 区服名字(必填)
			gameInfor1.setService_id("10086"); // 区服id(必填)
			SuperHelper.geApi().canEnter(gameInfor1, new CanEnterListen() {

				@Override
				public void canEnterListen(boolean b) {
					// TODO Auto-generated method stub
					tv_userInfo.setText("是否允许新增" + b);
					iscanenter = b;
				}
			});

			break;
		case R.id.btn_uploadUserInfo: // 角色上报
			// 如果允许新增,则进入游戏调用角色接口
			if (iscanenter) {
				GameInfor gameInfor = new GameInfor();
				gameInfor.setRole_type("createrole"); // 角色上报类型: createrole 创建角色
														// //levelup 升级角色//
														// ///enterserver
														// 进入服务器调用
				gameInfor.setService_name("测试服1"); // 区服名字(必填)
				// gameInfor.setService_id("10086"); // 区服id(必填)
				// gameInfor.setRole_id("123"); // 角色id(必填)
				gameInfor.setService_id("5099"); // 区服id(必填)
				gameInfor.setRole_id("509900091"); // 角色id(必填)
				gameInfor.setRole_name("慕容狗蛋"); // 角色名字(必填)
				gameInfor.setRole_level("1"); // 角色等级数字.int类型(必填,首次创建默认0级)
				gameInfor.setDescribe(""); // 角色描述(选填,默认为"")
				gameInfor.setMoney("0"); // 金额(选填,默认为0)
				gameInfor.setExperience("1"); // 角色经验(选填,默认为1,可以填写等级)
				gameInfor.setVip("1"); // 角色VIP(选填,默认为1)
				gameInfor.setPartyName(""); // 角色工会(选填,默认为"")
				gameInfor.setRole_time(System.currentTimeMillis() + ""); // 角色变化时间(必填,默认为当前时间)
				SuperHelper.geApi().setData(gameInfor, new GameInforListen() {

					@Override
					public void defeat(String defeat) {
						tv_userInfo.setTextColor(Color.RED);
						tv_userInfo.setText("上报角色失败" + "\n" + "" + defeat);
						Log.e("zkf", "角色上报失败" + defeat);
					}

					@Override
					public void game_info_success(String json) {
						tv_userInfo.setTextColor(Color.BLACK);
						tv_userInfo.setText("上报角色成功" + "\n" + "" + json);
						Log.e("zkf", "角色上报成功" + json);
					}

					@Override
					public void game_info_defeat(String reason) {
						tv_userInfo.setTextColor(Color.RED);
						tv_userInfo.setText("上报角色失败" + "\n" + "" + reason);
						Log.e("zkf", "角色上报失败" + reason);
					}
				});
			}

			break;
		case R.id.btn_pay:
			String money = edit_pay.getText().toString().trim();
			if (null == money || "".equals(money)) {
				money = 1 + "";
			}
			SupersdkPay supersdkPay = new SupersdkPay();
			supersdkPay.setCount(1); // 商品数量,(必填默认1)
			supersdkPay.setGame_order_sn(System.currentTimeMillis() + ""); // 订单号(必填)
			supersdkPay.setGood_id("123"); // 商品id(必填)
			supersdkPay.setGood_name("方天画戟削苹果"); // 商品名字(必填)
			supersdkPay.setMoney(1); // 金额(必填float类型)
			supersdkPay.setPay_time(System.currentTimeMillis() + ""); // 支付时间(必填,没有填当前时间)
			supersdkPay.setRemark("remark"); // 扩展参数(选填,没有填"remark",不能为空)
			supersdkPay.setRole_id("123"); // 角色id(必填)
			supersdkPay.setRole_name("慕容狗蛋"); // 角色名字(必填)
			supersdkPay.setRole_level("111");// 角色经验
			supersdkPay.setService_id("10086"); // 服务器id(必填)
			supersdkPay.setService_name("测试服1"); // 服务器名字(必填)
			SuperHelper.geApi().pay(supersdkPay, new PayListen() {

				@Override
				public void defeat(String defeat) {
					tv_userInfo.setTextColor(Color.RED);
					tv_userInfo.setText("上报支付失败" + "\n" + "" + defeat);
					Log.e("zkf", "支付上报失败" + defeat);
				}

				@Override
				public void pay_success(String json) {
					tv_userInfo.setTextColor(Color.BLACK);
					tv_userInfo.setText("上报支付成功" + "\n" + "" + json);
					Log.e("zkf", "支付上报成功" + json);
				}

				@Override
				public void pay_defeat(String string) {
					tv_userInfo.setTextColor(Color.RED);
					tv_userInfo.setText("上报支付失败" + "\n" + "" + string);
					Log.e("zkf", "支付上报失败" + string);
				}
			});
			break;
		case R.id.btn_finish:
			SuperHelper.geApi().EndGame(new LogoutGameListen() {

				@Override
				public void confirm() {
					Log.e("zkf", "我是游戏退出方法");
					System.out.println("我是游戏退出方法");
					finish();
					// 这里要调用游戏的退出.如System.exit(0).确保完全退出
					System.exit(0); // 在退出游戏时候请调用此方法,确保完全退出
				}

				@Override
				public void cancel() {
					Log.e("zkf", "我是游戏取消方法");
					System.out.println("我是游戏取消方法");
				}
			});
			break;

		}

	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// 这里请直接重写聚合方法.不要继承super
		superHelper.activity_save_instance_state(outState);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// 这里请直接重写聚合方法.不要继承super
		superHelper.activity_restore_instance_state(savedInstanceState);
	}

	@Override
	protected void onStart() {
		super.onStart();
		superHelper.activity_start();
	}

	@Override
	protected void onPause() {
		super.onPause();
		superHelper.activity_pause();
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		superHelper.activity_restart();
	}

	@Override
	protected void onResume() {
		super.onResume();
		superHelper.activity_resume();
	}

	@Override
	protected void onStop() {
		super.onStop();
		superHelper.activity_stop();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		superHelper.activity_destroy();
	}

	@TargetApi(23)
	@Override
	public void onRequestPermissionsResult(int requestCode,
			String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		superHelper.activity_RequestPermissionsResult(requestCode, permissions,
				grantResults);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		superHelper.activity_Result(requestCode, resultCode, data);
		super.onActivityResult(requestCode, resultCode, data);
		
	}
	
	@Override
	protected void onNewIntent(Intent intent) {
		superHelper.activity_newIntent(intent);
		super.onNewIntent(intent);
		
	}
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		superHelper.activity_configurationChanged(newConfig);
		super.onConfigurationChanged(newConfig);
	}


	@Override
	public void onBackPressed() {
		SuperHelper.geApi().EndGame(new LogoutGameListen() {

			@Override
			public void confirm() {
				System.out.println("我是游戏退出方法");
				finish();
				// 这里要调用游戏的退出.如System.exit(0).确保完全退出
				System.exit(0); // 在退出游戏时候请调用此方法,确保完全退出
			}

			@Override
			public void cancel() {
				System.out.println("我是游戏取消方法");
			}
		});
	}
}
